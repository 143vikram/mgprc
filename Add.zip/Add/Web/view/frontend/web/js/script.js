define([
    "jquery",
    "Magento_Catalog/js/product/list/toolbar",
], function ($) {
    /**
     * ProductListToolbarForm Widget - this widget is setting cookie and submitting form according to toolbar controls
     */
    
});
